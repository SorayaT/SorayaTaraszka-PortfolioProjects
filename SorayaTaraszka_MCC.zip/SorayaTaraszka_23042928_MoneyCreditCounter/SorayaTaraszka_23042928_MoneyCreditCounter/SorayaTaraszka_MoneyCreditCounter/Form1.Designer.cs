﻿namespace SorayaTaraszka_MoneyCreditCounter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.onePencePictureBox = new System.Windows.Forms.PictureBox();
            this.creditInput = new System.Windows.Forms.TextBox();
            this.twoPencePictureBox = new System.Windows.Forms.PictureBox();
            this.twentyPencePictureBox = new System.Windows.Forms.PictureBox();
            this.fiftyPencePictureBox = new System.Windows.Forms.PictureBox();
            this.fivePencePictureBox = new System.Windows.Forms.PictureBox();
            this.onePoundPictureBox = new System.Windows.Forms.PictureBox();
            this.tenPencePictureBox = new System.Windows.Forms.PictureBox();
            this.twoPoundPictureBox = new System.Windows.Forms.PictureBox();
            this.onePenceImage = new System.Windows.Forms.PictureBox();
            this.twoPenceImage = new System.Windows.Forms.PictureBox();
            this.fivePenceImage = new System.Windows.Forms.PictureBox();
            this.twentyPenceImage = new System.Windows.Forms.PictureBox();
            this.tenPenceImage = new System.Windows.Forms.PictureBox();
            this.fiftyPenceImage = new System.Windows.Forms.PictureBox();
            this.onePoundImage = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.CoinsEntered = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.Coins = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.x1 = new System.Windows.Forms.Label();
            this.x2 = new System.Windows.Forms.Label();
            this.x3 = new System.Windows.Forms.Label();
            this.x4 = new System.Windows.Forms.Label();
            this.x5 = new System.Windows.Forms.Label();
            this.x6 = new System.Windows.Forms.Label();
            this.x7 = new System.Windows.Forms.Label();
            this.x8 = new System.Windows.Forms.Label();
            this.onePennyLabel = new System.Windows.Forms.Label();
            this.twoPenceLabel = new System.Windows.Forms.Label();
            this.FivePenceLabel = new System.Windows.Forms.Label();
            this.tenPenceLabel = new System.Windows.Forms.Label();
            this.twentyPenceLabel = new System.Windows.Forms.Label();
            this.fiftyPenceLabel = new System.Windows.Forms.Label();
            this.onePoundLabel = new System.Windows.Forms.Label();
            this.twoPoundLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.valueInPoundsTB = new System.Windows.Forms.TextBox();
            this.Title1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.amountOfCredits = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.onePencePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoPencePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyPencePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyPencePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePencePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onePoundPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenPencePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoPoundPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onePenceImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoPenceImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePenceImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyPenceImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenPenceImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyPenceImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onePoundImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.AllowDrop = true;
            this.textBox1.Location = new System.Drawing.Point(123, 504);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(52, 20);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "0";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // onePencePictureBox
            // 
            this.onePencePictureBox.BackColor = System.Drawing.Color.White;
            this.onePencePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("onePencePictureBox.Image")));
            this.onePencePictureBox.Location = new System.Drawing.Point(32, 122);
            this.onePencePictureBox.Name = "onePencePictureBox";
            this.onePencePictureBox.Size = new System.Drawing.Size(61, 54);
            this.onePencePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.onePencePictureBox.TabIndex = 18;
            this.onePencePictureBox.TabStop = false;
            this.onePencePictureBox.Click += new System.EventHandler(this.onePencePictureBox_Click);
            // 
            // creditInput
            // 
            this.creditInput.Location = new System.Drawing.Point(229, 560);
            this.creditInput.Name = "creditInput";
            this.creditInput.Size = new System.Drawing.Size(59, 20);
            this.creditInput.TabIndex = 19;
            this.creditInput.Text = "0";
            this.creditInput.TextChanged += new System.EventHandler(this.creditInput_TextChanged);
            // 
            // twoPencePictureBox
            // 
            this.twoPencePictureBox.BackColor = System.Drawing.Color.White;
            this.twoPencePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("twoPencePictureBox.Image")));
            this.twoPencePictureBox.Location = new System.Drawing.Point(32, 207);
            this.twoPencePictureBox.Name = "twoPencePictureBox";
            this.twoPencePictureBox.Size = new System.Drawing.Size(69, 64);
            this.twoPencePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twoPencePictureBox.TabIndex = 20;
            this.twoPencePictureBox.TabStop = false;
            this.twoPencePictureBox.Click += new System.EventHandler(this.twoPencePictureBox_Click);
            // 
            // twentyPencePictureBox
            // 
            this.twentyPencePictureBox.BackColor = System.Drawing.Color.White;
            this.twentyPencePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("twentyPencePictureBox.Image")));
            this.twentyPencePictureBox.Location = new System.Drawing.Point(236, 122);
            this.twentyPencePictureBox.Name = "twentyPencePictureBox";
            this.twentyPencePictureBox.Size = new System.Drawing.Size(63, 57);
            this.twentyPencePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twentyPencePictureBox.TabIndex = 21;
            this.twentyPencePictureBox.TabStop = false;
            this.twentyPencePictureBox.Click += new System.EventHandler(this.twentyPencePictureBox_Click);
            // 
            // fiftyPencePictureBox
            // 
            this.fiftyPencePictureBox.BackColor = System.Drawing.Color.White;
            this.fiftyPencePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("fiftyPencePictureBox.Image")));
            this.fiftyPencePictureBox.Location = new System.Drawing.Point(227, 192);
            this.fiftyPencePictureBox.Name = "fiftyPencePictureBox";
            this.fiftyPencePictureBox.Size = new System.Drawing.Size(85, 80);
            this.fiftyPencePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fiftyPencePictureBox.TabIndex = 22;
            this.fiftyPencePictureBox.TabStop = false;
            this.fiftyPencePictureBox.Click += new System.EventHandler(this.fiftyPencePictureBox_Click);
            // 
            // fivePencePictureBox
            // 
            this.fivePencePictureBox.BackColor = System.Drawing.Color.White;
            this.fivePencePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("fivePencePictureBox.Image")));
            this.fivePencePictureBox.Location = new System.Drawing.Point(41, 317);
            this.fivePencePictureBox.Name = "fivePencePictureBox";
            this.fivePencePictureBox.Size = new System.Drawing.Size(52, 53);
            this.fivePencePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fivePencePictureBox.TabIndex = 23;
            this.fivePencePictureBox.TabStop = false;
            this.fivePencePictureBox.Click += new System.EventHandler(this.fivePencePictureBox_Click);
            // 
            // onePoundPictureBox
            // 
            this.onePoundPictureBox.BackColor = System.Drawing.Color.White;
            this.onePoundPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("onePoundPictureBox.Image")));
            this.onePoundPictureBox.Location = new System.Drawing.Point(227, 292);
            this.onePoundPictureBox.Name = "onePoundPictureBox";
            this.onePoundPictureBox.Size = new System.Drawing.Size(81, 78);
            this.onePoundPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.onePoundPictureBox.TabIndex = 24;
            this.onePoundPictureBox.TabStop = false;
            this.onePoundPictureBox.Click += new System.EventHandler(this.onePoundPictureBox_Click);
            // 
            // tenPencePictureBox
            // 
            this.tenPencePictureBox.BackColor = System.Drawing.Color.White;
            this.tenPencePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("tenPencePictureBox.Image")));
            this.tenPencePictureBox.Location = new System.Drawing.Point(37, 417);
            this.tenPencePictureBox.Name = "tenPencePictureBox";
            this.tenPencePictureBox.Size = new System.Drawing.Size(64, 63);
            this.tenPencePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tenPencePictureBox.TabIndex = 25;
            this.tenPencePictureBox.TabStop = false;
            this.tenPencePictureBox.Click += new System.EventHandler(this.tenPencePictureBox_Click);
            // 
            // twoPoundPictureBox
            // 
            this.twoPoundPictureBox.BackColor = System.Drawing.Color.White;
            this.twoPoundPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("twoPoundPictureBox.Image")));
            this.twoPoundPictureBox.Location = new System.Drawing.Point(226, 400);
            this.twoPoundPictureBox.Name = "twoPoundPictureBox";
            this.twoPoundPictureBox.Size = new System.Drawing.Size(82, 80);
            this.twoPoundPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twoPoundPictureBox.TabIndex = 26;
            this.twoPoundPictureBox.TabStop = false;
            this.twoPoundPictureBox.Click += new System.EventHandler(this.twoPoundPictureBox_Click);
            // 
            // onePenceImage
            // 
            this.onePenceImage.BackColor = System.Drawing.Color.White;
            this.onePenceImage.Image = ((System.Drawing.Image)(resources.GetObject("onePenceImage.Image")));
            this.onePenceImage.Location = new System.Drawing.Point(534, 20);
            this.onePenceImage.Name = "onePenceImage";
            this.onePenceImage.Size = new System.Drawing.Size(61, 54);
            this.onePenceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.onePenceImage.TabIndex = 27;
            this.onePenceImage.TabStop = false;
            // 
            // twoPenceImage
            // 
            this.twoPenceImage.BackColor = System.Drawing.Color.White;
            this.twoPenceImage.Image = ((System.Drawing.Image)(resources.GetObject("twoPenceImage.Image")));
            this.twoPenceImage.Location = new System.Drawing.Point(526, 80);
            this.twoPenceImage.Name = "twoPenceImage";
            this.twoPenceImage.Size = new System.Drawing.Size(69, 64);
            this.twoPenceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twoPenceImage.TabIndex = 28;
            this.twoPenceImage.TabStop = false;
            // 
            // fivePenceImage
            // 
            this.fivePenceImage.BackColor = System.Drawing.Color.White;
            this.fivePenceImage.Image = ((System.Drawing.Image)(resources.GetObject("fivePenceImage.Image")));
            this.fivePenceImage.Location = new System.Drawing.Point(535, 151);
            this.fivePenceImage.Name = "fivePenceImage";
            this.fivePenceImage.Size = new System.Drawing.Size(52, 54);
            this.fivePenceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fivePenceImage.TabIndex = 29;
            this.fivePenceImage.TabStop = false;
            this.fivePenceImage.Click += new System.EventHandler(this.fivePenceImage_Click);
            // 
            // twentyPenceImage
            // 
            this.twentyPenceImage.BackColor = System.Drawing.Color.White;
            this.twentyPenceImage.Image = ((System.Drawing.Image)(resources.GetObject("twentyPenceImage.Image")));
            this.twentyPenceImage.Location = new System.Drawing.Point(527, 280);
            this.twentyPenceImage.Name = "twentyPenceImage";
            this.twentyPenceImage.Size = new System.Drawing.Size(63, 58);
            this.twentyPenceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.twentyPenceImage.TabIndex = 30;
            this.twentyPenceImage.TabStop = false;
            // 
            // tenPenceImage
            // 
            this.tenPenceImage.BackColor = System.Drawing.Color.White;
            this.tenPenceImage.Image = ((System.Drawing.Image)(resources.GetObject("tenPenceImage.Image")));
            this.tenPenceImage.Location = new System.Drawing.Point(526, 211);
            this.tenPenceImage.Name = "tenPenceImage";
            this.tenPenceImage.Size = new System.Drawing.Size(64, 63);
            this.tenPenceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tenPenceImage.TabIndex = 31;
            this.tenPenceImage.TabStop = false;
            // 
            // fiftyPenceImage
            // 
            this.fiftyPenceImage.BackColor = System.Drawing.Color.White;
            this.fiftyPenceImage.Image = ((System.Drawing.Image)(resources.GetObject("fiftyPenceImage.Image")));
            this.fiftyPenceImage.Location = new System.Drawing.Point(521, 344);
            this.fiftyPenceImage.Name = "fiftyPenceImage";
            this.fiftyPenceImage.Size = new System.Drawing.Size(85, 80);
            this.fiftyPenceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fiftyPenceImage.TabIndex = 32;
            this.fiftyPenceImage.TabStop = false;
            // 
            // onePoundImage
            // 
            this.onePoundImage.BackColor = System.Drawing.Color.White;
            this.onePoundImage.Image = ((System.Drawing.Image)(resources.GetObject("onePoundImage.Image")));
            this.onePoundImage.Location = new System.Drawing.Point(524, 430);
            this.onePoundImage.Name = "onePoundImage";
            this.onePoundImage.Size = new System.Drawing.Size(82, 78);
            this.onePoundImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.onePoundImage.TabIndex = 33;
            this.onePoundImage.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(524, 514);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(82, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleShape1,
            this.CoinsEntered,
            this.Coins});
            this.shapeContainer1.Size = new System.Drawing.Size(632, 700);
            this.shapeContainer1.TabIndex = 35;
            this.shapeContainer1.TabStop = false;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape1.Location = new System.Drawing.Point(9, 542);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(338, 83);
            // 
            // CoinsEntered
            // 
            this.CoinsEntered.BackColor = System.Drawing.Color.White;
            this.CoinsEntered.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.CoinsEntered.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.CoinsEntered.Location = new System.Drawing.Point(377, 18);
            this.CoinsEntered.Name = "CoinsEntered";
            this.CoinsEntered.Size = new System.Drawing.Size(237, 652);
            this.CoinsEntered.Click += new System.EventHandler(this.CoinsEntered_Click);
            // 
            // Coins
            // 
            this.Coins.AccessibleDescription = "Coins";
            this.Coins.AccessibleName = "Coins";
            this.Coins.AccessibleRole = System.Windows.Forms.AccessibleRole.Outline;
            this.Coins.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Coins.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.Coins.BorderColor = System.Drawing.SystemColors.ControlLight;
            this.Coins.FillColor = System.Drawing.Color.White;
            this.Coins.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.Coins.Location = new System.Drawing.Point(10, 18);
            this.Coins.Name = "Coins";
            this.Coins.Size = new System.Drawing.Size(338, 516);
            this.Coins.Click += new System.EventHandler(this.Coins_Click);
            // 
            // x1
            // 
            this.x1.AutoSize = true;
            this.x1.BackColor = System.Drawing.Color.White;
            this.x1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x1.Location = new System.Drawing.Point(470, 31);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(32, 31);
            this.x1.TabIndex = 36;
            this.x1.Text = "X";
            // 
            // x2
            // 
            this.x2.AutoSize = true;
            this.x2.BackColor = System.Drawing.Color.White;
            this.x2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x2.Location = new System.Drawing.Point(470, 97);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(32, 31);
            this.x2.TabIndex = 36;
            this.x2.Text = "X";
            // 
            // x3
            // 
            this.x3.AutoSize = true;
            this.x3.BackColor = System.Drawing.Color.White;
            this.x3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x3.Location = new System.Drawing.Point(470, 163);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(32, 31);
            this.x3.TabIndex = 36;
            this.x3.Text = "X";
            // 
            // x4
            // 
            this.x4.AutoSize = true;
            this.x4.BackColor = System.Drawing.Color.White;
            this.x4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x4.Location = new System.Drawing.Point(470, 224);
            this.x4.Name = "x4";
            this.x4.Size = new System.Drawing.Size(32, 31);
            this.x4.TabIndex = 36;
            this.x4.Text = "X";
            // 
            // x5
            // 
            this.x5.AutoSize = true;
            this.x5.BackColor = System.Drawing.Color.White;
            this.x5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x5.Location = new System.Drawing.Point(470, 290);
            this.x5.Name = "x5";
            this.x5.Size = new System.Drawing.Size(32, 31);
            this.x5.TabIndex = 36;
            this.x5.Text = "X";
            // 
            // x6
            // 
            this.x6.AutoSize = true;
            this.x6.BackColor = System.Drawing.Color.White;
            this.x6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x6.Location = new System.Drawing.Point(470, 362);
            this.x6.Name = "x6";
            this.x6.Size = new System.Drawing.Size(32, 31);
            this.x6.TabIndex = 36;
            this.x6.Text = "X";
            // 
            // x7
            // 
            this.x7.AutoSize = true;
            this.x7.BackColor = System.Drawing.Color.White;
            this.x7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x7.Location = new System.Drawing.Point(470, 449);
            this.x7.Name = "x7";
            this.x7.Size = new System.Drawing.Size(32, 31);
            this.x7.TabIndex = 36;
            this.x7.Text = "X";
            // 
            // x8
            // 
            this.x8.AutoSize = true;
            this.x8.BackColor = System.Drawing.Color.White;
            this.x8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.x8.Location = new System.Drawing.Point(470, 529);
            this.x8.Name = "x8";
            this.x8.Size = new System.Drawing.Size(32, 31);
            this.x8.TabIndex = 36;
            this.x8.Text = "X";
            // 
            // onePennyLabel
            // 
            this.onePennyLabel.AutoSize = true;
            this.onePennyLabel.BackColor = System.Drawing.Color.White;
            this.onePennyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.onePennyLabel.Location = new System.Drawing.Point(414, 31);
            this.onePennyLabel.Name = "onePennyLabel";
            this.onePennyLabel.Size = new System.Drawing.Size(29, 31);
            this.onePennyLabel.TabIndex = 37;
            this.onePennyLabel.Text = "0";
            this.onePennyLabel.Click += new System.EventHandler(this.onePennyLabel_Click);
            // 
            // twoPenceLabel
            // 
            this.twoPenceLabel.AutoSize = true;
            this.twoPenceLabel.BackColor = System.Drawing.Color.White;
            this.twoPenceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.twoPenceLabel.Location = new System.Drawing.Point(414, 97);
            this.twoPenceLabel.Name = "twoPenceLabel";
            this.twoPenceLabel.Size = new System.Drawing.Size(29, 31);
            this.twoPenceLabel.TabIndex = 38;
            this.twoPenceLabel.Text = "0";
            this.twoPenceLabel.Click += new System.EventHandler(this.twoPenceLabel_Click);
            // 
            // FivePenceLabel
            // 
            this.FivePenceLabel.AutoSize = true;
            this.FivePenceLabel.BackColor = System.Drawing.Color.White;
            this.FivePenceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.FivePenceLabel.Location = new System.Drawing.Point(414, 163);
            this.FivePenceLabel.Name = "FivePenceLabel";
            this.FivePenceLabel.Size = new System.Drawing.Size(29, 31);
            this.FivePenceLabel.TabIndex = 39;
            this.FivePenceLabel.Text = "0";
            this.FivePenceLabel.Click += new System.EventHandler(this.FivePenceLabel_Click);
            // 
            // tenPenceLabel
            // 
            this.tenPenceLabel.AutoSize = true;
            this.tenPenceLabel.BackColor = System.Drawing.Color.White;
            this.tenPenceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tenPenceLabel.Location = new System.Drawing.Point(414, 224);
            this.tenPenceLabel.Name = "tenPenceLabel";
            this.tenPenceLabel.Size = new System.Drawing.Size(29, 31);
            this.tenPenceLabel.TabIndex = 40;
            this.tenPenceLabel.Text = "0";
            this.tenPenceLabel.Click += new System.EventHandler(this.tenPenceLabel_Click);
            // 
            // twentyPenceLabel
            // 
            this.twentyPenceLabel.AutoSize = true;
            this.twentyPenceLabel.BackColor = System.Drawing.Color.White;
            this.twentyPenceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.twentyPenceLabel.Location = new System.Drawing.Point(414, 290);
            this.twentyPenceLabel.Name = "twentyPenceLabel";
            this.twentyPenceLabel.Size = new System.Drawing.Size(29, 31);
            this.twentyPenceLabel.TabIndex = 41;
            this.twentyPenceLabel.Text = "0";
            this.twentyPenceLabel.Click += new System.EventHandler(this.twentyPenceLabel_Click);
            // 
            // fiftyPenceLabel
            // 
            this.fiftyPenceLabel.AutoSize = true;
            this.fiftyPenceLabel.BackColor = System.Drawing.Color.White;
            this.fiftyPenceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.fiftyPenceLabel.Location = new System.Drawing.Point(414, 362);
            this.fiftyPenceLabel.Name = "fiftyPenceLabel";
            this.fiftyPenceLabel.Size = new System.Drawing.Size(29, 31);
            this.fiftyPenceLabel.TabIndex = 42;
            this.fiftyPenceLabel.Text = "0";
            this.fiftyPenceLabel.Click += new System.EventHandler(this.fiftyPenceLabel_Click);
            // 
            // onePoundLabel
            // 
            this.onePoundLabel.AutoSize = true;
            this.onePoundLabel.BackColor = System.Drawing.Color.White;
            this.onePoundLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.onePoundLabel.Location = new System.Drawing.Point(414, 449);
            this.onePoundLabel.Name = "onePoundLabel";
            this.onePoundLabel.Size = new System.Drawing.Size(29, 31);
            this.onePoundLabel.TabIndex = 43;
            this.onePoundLabel.Text = "0";
            this.onePoundLabel.Click += new System.EventHandler(this.onePoundLabel_Click);
            // 
            // twoPoundLabel
            // 
            this.twoPoundLabel.AutoSize = true;
            this.twoPoundLabel.BackColor = System.Drawing.Color.White;
            this.twoPoundLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.twoPoundLabel.Location = new System.Drawing.Point(414, 529);
            this.twoPoundLabel.Name = "twoPoundLabel";
            this.twoPoundLabel.Size = new System.Drawing.Size(29, 31);
            this.twoPoundLabel.TabIndex = 44;
            this.twoPoundLabel.Text = "0";
            this.twoPoundLabel.Click += new System.EventHandler(this.twoPoundLabel_Click);
            // 
            // resetButton
            // 
            this.resetButton.BackColor = System.Drawing.Color.Red;
            this.resetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.resetButton.Location = new System.Drawing.Point(16, 642);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(262, 43);
            this.resetButton.TabIndex = 45;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = false;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // valueInPoundsTB
            // 
            this.valueInPoundsTB.Location = new System.Drawing.Point(226, 504);
            this.valueInPoundsTB.Name = "valueInPoundsTB";
            this.valueInPoundsTB.Size = new System.Drawing.Size(85, 20);
            this.valueInPoundsTB.TabIndex = 46;
            this.valueInPoundsTB.Text = "0.00";
            this.valueInPoundsTB.TextChanged += new System.EventHandler(this.valueInPoundsTB_TextChanged);
            // 
            // Title1
            // 
            this.Title1.AutoSize = true;
            this.Title1.BackColor = System.Drawing.Color.White;
            this.Title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Title1.Location = new System.Drawing.Point(100, 31);
            this.Title1.Name = "Title1";
            this.Title1.Size = new System.Drawing.Size(159, 31);
            this.Title1.TabIndex = 48;
            this.Title1.Text = "Click a Coin";
            this.Title1.Click += new System.EventHandler(this.Title1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(204, 508);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 16);
            this.label1.TabIndex = 49;
            this.label1.Text = "£";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(317, 505);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 16);
            this.label2.TabIndex = 50;
            this.label2.Text = "p";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(181, 505);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 16);
            this.label3.TabIndex = 51;
            this.label3.Text = "p";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(12, 502);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 24);
            this.label4.TabIndex = 52;
            this.label4.Text = "Total Value";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(13, 561);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(213, 15);
            this.label5.TabIndex = 53;
            this.label5.Text = "Please Enter the Cost Per Credit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(13, 604);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(246, 13);
            this.label6.TabIndex = 54;
            this.label6.Text = "You Presently Have this amount of Credits";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(81, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(194, 31);
            this.label7.TabIndex = 55;
            this.label7.Text = "To Buy Credits";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(298, 565);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 15);
            this.label8.TabIndex = 56;
            this.label8.Text = "p";
            // 
            // amountOfCredits
            // 
            this.amountOfCredits.Location = new System.Drawing.Point(265, 603);
            this.amountOfCredits.Name = "amountOfCredits";
            this.amountOfCredits.Size = new System.Drawing.Size(68, 20);
            this.amountOfCredits.TabIndex = 57;
            this.amountOfCredits.Text = "0";
            this.amountOfCredits.TextChanged += new System.EventHandler(this.amountOfCredits_TextChanged);
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(632, 700);
            this.Controls.Add(this.amountOfCredits);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Title1);
            this.Controls.Add(this.valueInPoundsTB);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.twoPoundLabel);
            this.Controls.Add(this.onePoundLabel);
            this.Controls.Add(this.fiftyPenceLabel);
            this.Controls.Add(this.twentyPenceLabel);
            this.Controls.Add(this.tenPenceLabel);
            this.Controls.Add(this.FivePenceLabel);
            this.Controls.Add(this.twoPenceLabel);
            this.Controls.Add(this.onePennyLabel);
            this.Controls.Add(this.x8);
            this.Controls.Add(this.x7);
            this.Controls.Add(this.x6);
            this.Controls.Add(this.x5);
            this.Controls.Add(this.x4);
            this.Controls.Add(this.x3);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.x1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.onePoundImage);
            this.Controls.Add(this.fiftyPenceImage);
            this.Controls.Add(this.tenPenceImage);
            this.Controls.Add(this.twentyPenceImage);
            this.Controls.Add(this.fivePenceImage);
            this.Controls.Add(this.twoPenceImage);
            this.Controls.Add(this.onePenceImage);
            this.Controls.Add(this.twoPoundPictureBox);
            this.Controls.Add(this.tenPencePictureBox);
            this.Controls.Add(this.onePoundPictureBox);
            this.Controls.Add(this.fivePencePictureBox);
            this.Controls.Add(this.fiftyPencePictureBox);
            this.Controls.Add(this.twentyPencePictureBox);
            this.Controls.Add(this.twoPencePictureBox);
            this.Controls.Add(this.creditInput);
            this.Controls.Add(this.onePencePictureBox);
            this.Controls.Add(this.shapeContainer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Money Credit Counter 2.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.onePencePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoPencePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyPencePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyPencePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePencePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onePoundPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenPencePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoPoundPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onePenceImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoPenceImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePenceImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twentyPenceImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenPenceImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiftyPenceImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onePoundImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox onePencePictureBox;
        private System.Windows.Forms.TextBox creditInput;
        private System.Windows.Forms.PictureBox twoPencePictureBox;
        private System.Windows.Forms.PictureBox twentyPencePictureBox;
        private System.Windows.Forms.PictureBox fiftyPencePictureBox;
        private System.Windows.Forms.PictureBox fivePencePictureBox;
        private System.Windows.Forms.PictureBox onePoundPictureBox;
        private System.Windows.Forms.PictureBox tenPencePictureBox;
        private System.Windows.Forms.PictureBox twoPoundPictureBox;
        private System.Windows.Forms.PictureBox onePenceImage;
        private System.Windows.Forms.PictureBox twoPenceImage;
        private System.Windows.Forms.PictureBox fivePenceImage;
        private System.Windows.Forms.PictureBox twentyPenceImage;
        private System.Windows.Forms.PictureBox tenPenceImage;
        private System.Windows.Forms.PictureBox fiftyPenceImage;
        private System.Windows.Forms.PictureBox onePoundImage;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape CoinsEntered;
        protected Microsoft.VisualBasic.PowerPacks.RectangleShape Coins;
        private System.Windows.Forms.Label x1;
        private System.Windows.Forms.Label x2;
        private System.Windows.Forms.Label x3;
        private System.Windows.Forms.Label x4;
        private System.Windows.Forms.Label x5;
        private System.Windows.Forms.Label x6;
        private System.Windows.Forms.Label x7;
        private System.Windows.Forms.Label x8;
        private System.Windows.Forms.Label onePennyLabel;
        private System.Windows.Forms.Label twoPenceLabel;
        private System.Windows.Forms.Label FivePenceLabel;
        private System.Windows.Forms.Label tenPenceLabel;
        private System.Windows.Forms.Label twentyPenceLabel;
        private System.Windows.Forms.Label fiftyPenceLabel;
        private System.Windows.Forms.Label onePoundLabel;
        private System.Windows.Forms.Label twoPoundLabel;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.TextBox valueInPoundsTB;
        private System.Windows.Forms.Label Title1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox amountOfCredits;

    }
}

