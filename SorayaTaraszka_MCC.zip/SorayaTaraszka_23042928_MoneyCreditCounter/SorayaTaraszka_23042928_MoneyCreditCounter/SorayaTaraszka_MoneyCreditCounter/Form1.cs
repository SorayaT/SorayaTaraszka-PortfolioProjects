﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyDialogs;

namespace SorayaTaraszka_MoneyCreditCounter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int costPerCredit;
        int valueInPence;
        double totalvalue = 0;
        int onePenceClicked = 0;
        int twentyPenceClicked = 0;
        int twoPenceClicked = 0;
        int fiftyPenceClicked = 0;
        int fivePenceClicked = 0;
        int onePoundClicked = 0;
        int tenPenceClicked = 0;
        int twoPoundsClicked = 0;
        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void onePencePictureBox_Click(object sender, EventArgs e)
        {
            if (creditInput.Text == "0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                onePenceClicked++;
                totalvalue= totalvalue + 0.01;
                valueInPence = valueInPence + 1;
                textBox1.Text = valueInPence.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                onePennyLabel.Text = onePenceClicked.ToString();
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();
            }
        }

        private void twentyPencePictureBox_Click(object sender, EventArgs e)

        {
            if (creditInput.Text == "0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                twentyPenceClicked++;
                totalvalue = totalvalue + 0.20;
                valueInPence = valueInPence + 20;
                textBox1.Text = valueInPence.ToString();
                twentyPenceLabel.Text = twentyPenceClicked.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();
            }
        }

        private void twoPencePictureBox_Click(object sender, EventArgs e)
        {
            if (creditInput.Text == "0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                twoPenceClicked++;
                totalvalue = totalvalue + 0.02;
                valueInPence = valueInPence + 2;
                textBox1.Text = valueInPence.ToString();
                twoPenceLabel.Text = twoPenceClicked.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();
            }

        }

        private void fiftyPencePictureBox_Click(object sender, EventArgs e)
        {
            if (creditInput.Text=="0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                fiftyPenceClicked++;
                totalvalue = totalvalue + 0.50;
                valueInPence = valueInPence + 50;
                textBox1.Text = valueInPence.ToString();
                fiftyPenceLabel.Text = fiftyPenceClicked.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();
            }

        }

        private void fivePencePictureBox_Click(object sender, EventArgs e)
        {
            if (creditInput.Text=="0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                fivePenceClicked++;
                totalvalue = totalvalue + 0.05;
                valueInPence = valueInPence + 5;
                textBox1.Text = valueInPence.ToString();
                FivePenceLabel.Text = fivePenceClicked.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();
            }

        }

        private void onePoundPictureBox_Click(object sender, EventArgs e)
        {
            if (creditInput.Text=="0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                onePoundClicked++;
                totalvalue = totalvalue + 1;
                valueInPence = valueInPence + 100;
                textBox1.Text = valueInPence.ToString();
                onePoundLabel.Text = onePoundClicked.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();
            }

        }

        private void tenPencePictureBox_Click(object sender, EventArgs e)
        {
            if (creditInput.Text=="0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                tenPenceClicked++;
                totalvalue = totalvalue + 0.10;
                valueInPence = valueInPence + 10;
                textBox1.Text = valueInPence.ToString();
                tenPenceLabel.Text = tenPenceClicked.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();
            }

        }

        private void twoPoundPictureBox_Click(object sender, EventArgs e)
        {
            if (creditInput.Text=="0")
            {
                MessageBox.Show("You have not set the cost of a credit");
            }
            else
            {
                twoPoundsClicked++;
                totalvalue = totalvalue + 2;
                valueInPence = valueInPence + 200;
                textBox1.Text = valueInPence.ToString();
                twoPoundLabel.Text = twoPoundsClicked.ToString();
                valueInPoundsTB.Text = totalvalue.ToString("n2");
                amountOfCredits.Text = (valueInPence / Convert.ToInt32(creditInput.Text)).ToString();

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void onePennyLabel_Click(object sender, EventArgs e)
        {
            
        }

        private void twoPoundsTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void creditInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void fivePenceImage_Click(object sender, EventArgs e)
        {

        }

        private void twoPenceLabel_Click(object sender, EventArgs e)
        {

        }

        private void FivePenceLabel_Click(object sender, EventArgs e)
        {

        }

        private void tenPenceLabel_Click(object sender, EventArgs e)
        {

        }

        private void twentyPenceLabel_Click(object sender, EventArgs e)
        {

        }

        private void fiftyPenceLabel_Click(object sender, EventArgs e)
        {

        }

        private void onePoundLabel_Click(object sender, EventArgs e)
        {

        }

        private void twoPoundLabel_Click(object sender, EventArgs e)
        {

        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = 0.ToString();
            valueInPence = 0;

            valueInPoundsTB.Text = 0.ToString();
            totalvalue = 0;

            creditInput.Text = 0.ToString();
           costPerCredit = 0;

            onePennyLabel.Text = 0.ToString();
            onePenceClicked = 0;

            twoPenceLabel.Text = 0.ToString();
            twoPenceClicked = 0;

            FivePenceLabel.Text = 0.ToString();
            fivePenceClicked = 0;

            tenPenceLabel.Text=0.ToString();
            tenPenceClicked = 0;

            twentyPenceLabel.Text = 0.ToString();
            twentyPenceClicked = 0;

            fiftyPenceLabel.Text = 0.ToString();
            fiftyPenceClicked = 0;

            onePoundLabel.Text = 0.ToString();
            onePoundClicked = 0;

            twoPoundLabel.Text = 0.ToString();
            twoPoundsClicked = 0;

            amountOfCredits.Text = "0";


        }

        private void valueInPoundsTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void Title1_Click(object sender, EventArgs e)
        {

        }

        private void CoinsEntered_Click(object sender, EventArgs e)
        {

        }

        private void amountOfCredits_TextChanged(object sender, EventArgs e)
        {

        }

        private void Coins_Click(object sender, EventArgs e)
        {

        }





    }
}
